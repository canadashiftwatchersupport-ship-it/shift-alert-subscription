# Billing server starter

This is a minimal reference server for license verification and Razorpay webhook processing.

**Before production:**
- Use a real database instead of `licenses.json`.
- Add authenticated/admin tooling for refunds, cancellations, and manual revocation.
- Map Razorpay Payment Link IDs / subscription IDs explicitly to `day` and `monthly`; do not infer the plan from description text.
- Send the generated token through a real transactional email provider.
- Use HTTPS on the public server.
- Keep Razorpay API keys and webhook secret only on the server.
- Configure webhook signature validation using the raw request body.

Endpoints:
- `POST /api/razorpay/webhook`
- `POST /api/license/verify`
- `GET /health`

Razorpay webhook URLs must be public. Use the webhook secret from the Razorpay Dashboard and validate `X-Razorpay-Signature`.
