// Public configuration only. Never put Razorpay secret keys here.
const CONFIG = Object.freeze({
  LICENSE_API_BASE: "https://YOUR-BILLING-DOMAIN.example.com",
  RAZORPAY_DAY_PASS_URL: "https://rzp.io/l/REPLACE_DAY_PASS",
  RAZORPAY_MONTHLY_URL: "https://rzp.io/l/REPLACE_MONTHLY"
});
