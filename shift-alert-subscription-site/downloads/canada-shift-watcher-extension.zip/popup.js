const enabled = document.querySelector("#enabled");
const interval = document.querySelector("#interval");
const autoPrepare = document.querySelector("#autoPrepare");
const acceptAlternative = document.querySelector("#acceptAlternative");
const jobType = document.querySelector("#jobType");
const locationPreference = document.querySelector("#location");
const anywhereCanada = document.querySelector("#anywhereCanada");
const status = document.querySelector("#status");
const gate = document.querySelector("#paymentGate");
const settings = document.querySelector("#settings");
const email = document.querySelector("#email");
const token = document.querySelector("#token");
const licenseState = document.querySelector("#licenseState");

const storageGet = keys => new Promise(resolve => chrome.storage.local.get(keys, resolve));
const storageSet = obj => new Promise(resolve => chrome.storage.local.set(obj, resolve));

function validEmail(value) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value); }

async function verifyLicense(showMessage=true) {
  const data = await storageGet(["licenseEmail","licenseToken"]);
  if (!data.licenseEmail || !data.licenseToken) {
    if (showMessage) status.textContent = "No active license. Choose a plan below.";
    showGate();
    return false;
  }
  try {
    const response = await fetch(`${CONFIG.LICENSE_API_BASE.replace(/\/$/,"")}/api/license/verify`, {
      method:"POST", headers:{"Content-Type":"application/json"},
      body:JSON.stringify({email:data.licenseEmail, token:data.licenseToken})
    });
    if (!response.ok) throw new Error(`Server returned ${response.status}`);
    const result = await response.json();
    if (result.active) {
      await storageSet({licenseEmail:data.licenseEmail, licenseToken:data.licenseToken, licenseExpiresAt:result.expiresAt||null, licensePlan:result.plan||null});
      licenseState.innerHTML = `<span class="badge">License active${result.expiresAt ? ` · expires ${new Date(result.expiresAt).toLocaleDateString()}` : ""}</span>`;
      hideGate();
      if (showMessage) status.textContent = "License verified.";
      return true;
    }
    await storageSet({enabled:false});
    if (showMessage) status.textContent = result.reason || "License is not active.";
    showGate();
    return false;
  } catch (error) {
    if (showMessage) status.textContent = `Could not verify license: ${error.message}`;
    showGate();
    return false;
  }
}

function showGate(){ gate.style.display="block"; settings.classList.add("hidden"); }
function hideGate(){ gate.style.display="none"; settings.classList.remove("hidden"); }

async function startPayment(url) {
  const value=email.value.trim();
  if (!validEmail(value)) { status.textContent="Enter the email you will use at Razorpay checkout."; email.focus(); return; }
  await storageSet({checkoutEmail:value});
  chrome.tabs.create({url});
  status.textContent="Razorpay checkout opened. After payment, use the same email and activate your license.";
}

document.querySelector("#buyDay").addEventListener("click", () => startPayment(CONFIG.RAZORPAY_DAY_PASS_URL));
document.querySelector("#buyMonthly").addEventListener("click", () => startPayment(CONFIG.RAZORPAY_MONTHLY_URL));

document.querySelector("#activate").addEventListener("click", async () => {
  const e=email.value.trim(), t=token.value.trim();
  if (!validEmail(e) || !t) { status.textContent="Enter your checkout email and license token."; return; }
  await storageSet({licenseEmail:e, licenseToken:t});
  await verifyLicense(true);
});

document.querySelector("#refreshLicense").addEventListener("click", () => verifyLicense(true));

(async () => {
  const data = await storageGet(["enabled","intervalMinutes","autoPrepare","acceptAlternative","jobType","locationPreference","anywhereCanada","checkoutEmail","licenseEmail","licenseToken"]);
  enabled.checked=Boolean(data.enabled); interval.value=String(data.intervalMinutes||1);
  autoPrepare.checked=Boolean(data.autoPrepare); acceptAlternative.checked=Boolean(data.acceptAlternative);
  jobType.value=data.jobType||"any"; locationPreference.value=data.locationPreference||"";
  anywhereCanada.checked=Boolean(data.anywhereCanada); locationPreference.disabled=anywhereCanada.checked;
  email.value=data.licenseEmail||data.checkoutEmail||"";
  token.value=data.licenseToken||"";
  await verifyLicense(false);
})();

document.querySelector("#save").addEventListener("click", async () => {
  if (enabled.checked && !(await verifyLicense(false))) {
    enabled.checked=false; status.textContent="Payment is required before starting the watcher."; showGate(); return;
  }
  chrome.runtime.sendMessage({
    type:"set-enabled", enabled:enabled.checked, intervalMinutes:Number(interval.value),
    autoPrepare:autoPrepare.checked, acceptAlternative:acceptAlternative.checked,
    jobType:jobType.value, locationPreference:locationPreference.value.trim(),
    anywhereCanada:anywhereCanada.checked, resetSeen:true
  }, response => { status.textContent=response?.ok ? (enabled.checked ? "Watcher is running and scanning now." : "Watcher is stopped.") : "Could not save settings."; });
});

anywhereCanada.addEventListener("change",()=>{locationPreference.disabled=anywhereCanada.checked;});
document.querySelector("#open").addEventListener("click",()=>{chrome.runtime.sendMessage({type:"open-search"});window.close();});
document.querySelector("#resume").addEventListener("click",async()=>{
  if (!(await verifyLicense(false))) { status.textContent="Payment is required before resuming the watcher."; showGate(); return; }
  chrome.runtime.sendMessage({type:"resume-watching"},response=>{
    if(response?.ok){enabled.checked=true;status.textContent="Current application skipped. Watcher resumed.";}
    else status.textContent="Could not resume the watcher.";
  });
});
