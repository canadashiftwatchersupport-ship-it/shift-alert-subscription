import express from "express";
import crypto from "crypto";
import fs from "fs";
import path from "path";

const app = express();
const PORT = Number(process.env.PORT || 8080);
const DB = path.resolve(process.env.LICENSE_DB || "./licenses.json");
const WEBHOOK_SECRET = process.env.RAZORPAY_WEBHOOK_SECRET || "";

function loadDb() { try { return JSON.parse(fs.readFileSync(DB, "utf8")); } catch { return {licenses:{}, events:{}}; } }
function saveDb(db) { fs.writeFileSync(DB, JSON.stringify(db,null,2)); }
function token() { return crypto.randomBytes(24).toString("base64url"); }
function key(email, t) { return crypto.createHash("sha256").update(`${email.toLowerCase()}:${t}`).digest("hex"); }
function iso(ms) { return new Date(ms).toISOString(); }

app.get("/health", (_req,res)=>res.json({ok:true}));

app.use("/api/razorpay/webhook", express.raw({type:"application/json"}));
app.post("/api/razorpay/webhook", (req,res)=>{
  const signature=req.header("X-Razorpay-Signature")||"";
  if (!WEBHOOK_SECRET) return res.status(500).json({error:"Webhook secret not configured"});
  const expected=crypto.createHmac("sha256",WEBHOOK_SECRET).update(req.body).digest("hex");
  if (!crypto.timingSafeEqual(Buffer.from(signature),Buffer.from(expected))) return res.status(401).json({error:"Invalid signature"});
  let event; try { event=JSON.parse(req.body.toString("utf8")); } catch { return res.status(400).json({error:"Invalid JSON"}); }

  const db=loadDb();
  const eventId=event.id || crypto.createHash("sha256").update(req.body).digest("hex");
  if (db.events[eventId]) return res.json({ok:true,duplicate:true});
  db.events[eventId]=Date.now();

  // Tolerant extraction for common Razorpay Payment Link / Subscription payload shapes.
  const entity =
    event?.payload?.payment_link?.entity ||
    event?.payload?.subscription?.entity ||
    event?.payload?.payment?.entity || {};
  const customer = entity.customer || {};
  const email = (customer.email || entity.email || entity.customer_email || "").trim().toLowerCase();
  if (!email) { saveDb(db); return res.json({ok:true,ignored:"no email"}); }

  const eventName=event.event || "";
  let plan=null, expiresAt=null;
  if (eventName === "payment_link.paid" || eventName === "payment.paid" || eventName === "payment.captured") {
    // Identify Day Pass by the Payment Link's reference/description. Replace this logic
    // with your actual Payment Link ID mapping in production.
    const text=JSON.stringify(entity).toLowerCase();
    if (text.includes("day") || text.includes("24")) {
      plan="day";
      expiresAt=Date.now()+24*60*60*1000;
    }
  }
  if (eventName.startsWith("subscription.")) {
    plan="monthly";
    const end=entity.current_end ? Number(entity.current_end)*1000 : Date.now()+31*24*60*60*1000;
    expiresAt=end;
  }

  if (plan) {
    const t=token();
    db.licenses[key(email,t)]={email,token:t,plan,expiresAt,active:true,createdAt:Date.now(),sourceEvent:eventName};
    db.lastLicense={email,token:t,plan,expiresAt}; // replace with email service in production
  }
  saveDb(db);
  res.json({ok:true});
});

app.use(express.json());

app.post("/api/license/verify",(req,res)=>{
  const email=String(req.body?.email||"").trim().toLowerCase();
  const t=String(req.body?.token||"").trim();
  if (!email || !t) return res.status(400).json({active:false,reason:"Email and token are required"});
  const db=loadDb();
  const lic=db.licenses[key(email,t)];
  if (!lic || !lic.active) return res.json({active:false,reason:"License not found or inactive"});
  if (lic.expiresAt && Date.now()>lic.expiresAt) {
    lic.active=false; saveDb(db);
    return res.json({active:false,reason:"License expired"});
  }
  res.json({active:true,plan:lic.plan,expiresAt:iso(lic.expiresAt)});
});

app.listen(PORT,()=>console.log(`Billing server listening on ${PORT}`));
