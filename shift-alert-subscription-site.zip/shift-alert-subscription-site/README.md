# Canada Shift Watcher website

This folder contains the public website for Canada Shift Watcher, an independent Chrome extension that monitors matching Amazon job and shift listings, helps customers notice relevant opportunities faster, and keeps final review and submission manual.

## Public pages

- `index.html`
- `faq.html`
- `privacy.html`
- `terms.html`
- `refund.html`
- `contact.html`

## Pricing shown on the site

- Day Pass: C$15 for 24-hour access, one-time payment
- Monthly Pass: C$75/month recurring subscription

## Config values to edit

Open `config.js` and replace:

- `dayPassPaymentUrl` with your Razorpay Day Pass payment link
- `monthlySubscriptionUrl` with your Razorpay Monthly Subscription URL
- `chromeWebStoreUrl` with your Chrome Web Store listing URL
- `supportEmail` with your support email address

Do not place Razorpay secret keys, webhook secrets, or database credentials in any frontend file.

## What to publish

Upload these files together:

- `index.html`
- `faq.html`
- `privacy.html`
- `terms.html`
- `refund.html`
- `contact.html`
- `styles.css`
- `app.js`
- `config.js`
- `favicon.svg`
- `Canada-Shift-Watcher-paid-v1.4.1.zip`

## Before submitting to Razorpay

1. Confirm every navigation and footer link opens correctly.
2. Confirm both prices show C$15 and C$75, not USD.
3. Confirm payment buttons are not hard-coded to fake URLs.
4. Confirm privacy, terms, refund, and contact pages are publicly reachable.
5. Confirm the site language does not promise hiring, shifts, or successful applications.
6. Confirm the browser frontend contains no secret keys.
7. Publish the site and use the live public URL in your Razorpay review submission.
