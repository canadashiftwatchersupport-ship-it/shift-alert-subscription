window.CSW_CONFIG = {
  dayPassPaymentUrl: "",
  monthlySubscriptionUrl: "",
  chromeWebStoreUrl: "",
  supportEmail: "SUPPORT_EMAIL",
  businessName: "Canada Shift Watcher",
  businessCountry: "Canada"
};
